Challenges

### The participants have to complete the below challenge.


1. Go to http://rpachallenge.com/
2. Download the excel. 
3. Make a bot to complete the challenge.
4. After completing the bot record a video from start to end. 
5. Then finally print the total execution time and no of completed transactions in output panel.
6. Note:Your bot should show start & end time hh:mm:ss:ms in a messgae box.
7. Then fork this repo, upload your documents (zip file, workflow image & the video) then generate a pull request.

